MINICIV - UNIVERSIDAD CARLOS III DE MADRID 2015

ARGUMENTOS:
    --debug    Ejecuta una vez cada metodo de la plantilla.
    --spanish  Muestra la interfaz en espanol.
    --english  Muestra la interfaz en ingles.

ATAJOS DE TECLADO:

Doble clic = Reparar
Espacio = Siguiente turno
Flechas = Navegar por el mapa
S = Siguiente turno
P = Expandir frontera
R = Reparar
N = Subir de nivel
D = Demoler
F = Fundar ciudad
C = Construir Casa
A = Construir Aserradero
M = Construir Mina
G = Construir Granja
B = Construir Barco
L = Construir Colegio
T = Construir Cuartel
E = Construir Mercado



ARGUMENTS:
    --debug    Executes every method of the template one time.
    --spanish  Shows the interface in spanish.
    --english  Shows the interface in english.

KEYBOARD SHORTCUTS:

Double clic = Repair
Spacebar = Next Turn
Arrows = Navigate map
S = Next Turn
P = Expand border
R = Repair
N = Level Up (upgrade)
D = Demolish
F = Found city
C = Build House
A = Build Sawmill
M = Build Mine
G = Build Farm
B = Build Ship
L = Build School
T = Build Barracks
E = Build Market


